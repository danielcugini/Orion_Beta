const { SlashCommanderBuilder } = require("discord.js")

module.exports = {
    data: new SlashCommanderBuilder()
        .setName("ping")
        .setDescription("Replies with pong!"),

    async execute(interaction){
    await interaction.reply("Pong!")
    }
}